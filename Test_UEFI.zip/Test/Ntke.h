﻿#pragma once
#include "ntdef.h"
typedef struct _OBJECT_ATTRIBUTES {
	ULONG Length;
	HANDLE RootDirectory;
	PUNICODE_STRING ObjectName;
	ULONG Attributes;
	PVOID SecurityDescriptor;        // Points to type SECURITY_DESCRIPTOR
	PVOID SecurityQualityOfService;  // Points to type SECURITY_QUALITY_OF_SERVICE
} OBJECT_ATTRIBUTES;
typedef OBJECT_ATTRIBUTES *POBJECT_ATTRIBUTES;



typedef struct _CLIENT_ID {
	HANDLE UniqueProcess;
	HANDLE UniqueThread;
} CLIENT_ID;
typedef CLIENT_ID *PCLIENT_ID;

typedef struct _PS_CREATE_NOTIFY_INFO {
	UINT64              Size;
	union {
		ULONG Flags;
		struct {
			ULONG FileOpenNameAvailable : 1;
			ULONG IsSubsystemProcess : 1;
			ULONG Reserved : 30;
		};
	};
	HANDLE              ParentProcessId;
	CLIENT_ID           CreatingThreadId;
	struct _FILE_OBJECT *FileObject;
	PCUNICODE_STRING    ImageFileName;
	PCUNICODE_STRING    CommandLine;
	NTSTATUS            CreationStatus;
} PS_CREATE_NOTIFY_INFO, *PPS_CREATE_NOTIFY_INFO;


typedef NTSTATUS(NTAPI *pfnPsCreateSystemThread)(
	PHANDLE ThreadHandle,
	ULONG DesiredAccess,
	POBJECT_ATTRIBUTES ObjectAttributes,
	HANDLE ProcessHandle,
	PCLIENT_ID ClientId,
	void* StartRoutine,
	PVOID StartContext);

typedef PVOID(NTAPI *pfnMmGetSystemRoutineAddress)(
	PUNICODE_STRING SystemRoutineName
);




typedef
VOID
(*PCREATE_PROCESS_NOTIFY_ROUTINE_EX) (
	void* Process,
	HANDLE ProcessId,
	PPS_CREATE_NOTIFY_INFO CreateInfo
	);

typedef NTSTATUS(NTAPI *pfnPsSetCreateProcessNotifyRoutineEx)(
	PCREATE_PROCESS_NOTIFY_ROUTINE_EX NotifyRoutine,
	BOOLEAN                           Remove
);

typedef void(*pfnRtlInitUnicodeString)(
	PUNICODE_STRING         DestinationString,
	PCWSTR SourceString
);

typedef UCHAR*(NTAPI*pfnPsGetProcessImageFileName)(
	void* Process
);

typedef struct _KAPC_STATE
{
	LIST_ENTRY ApcListHead[MaximumMode];
	struct _KPROCESS *Process;
	union
	{
		UCHAR InProgressFlags;
		struct
		{
			BOOLEAN KernelApcInProgress : 1;
			BOOLEAN SpecialApcInProgress : 1;
		};
	};

	BOOLEAN KernelApcPending;
	BOOLEAN UserApcPending;
} KAPC_STATE, *PKAPC_STATE, *PRKAPC_STATE;

typedef struct _SYSTEM_SERVICE_DESCRIPTOR_TABLE
{
	PULONG_PTR ServiceTableBase;
	PULONG ServiceCounterTableBase;
	ULONG_PTR NumberOfServices;
	PUCHAR ParamTableBase;
} SYSTEM_SERVICE_DESCRIPTOR_TABLE, *PSYSTEM_SERVICE_DESCRIPTOR_TABLE;

typedef struct _NT_PROC_THREAD_ATTRIBUTE_ENTRY
{
	ULONG Attribute;    // PROC_THREAD_ATTRIBUTE_XXX
	UINT64 Size;
	ULONG_PTR Value;
	ULONG Unknown;
} NT_PROC_THREAD_ATTRIBUTE_ENTRY, *NT_PPROC_THREAD_ATTRIBUTE_ENTRY;

typedef struct _NT_PROC_THREAD_ATTRIBUTE_LIST
{
	ULONG Length;
	NT_PROC_THREAD_ATTRIBUTE_ENTRY Entry[1];
} NT_PROC_THREAD_ATTRIBUTE_LIST, *PNT_PROC_THREAD_ATTRIBUTE_LIST;



typedef void(*pfnKeStackAttachProcess)(
	void*   PROCESS,
	PRKAPC_STATE ApcState
	);

typedef long (*pfnZwAllocateVirtualMemory)(
	HANDLE ProcessHandle,
	PVOID *BaseAddress,
	UINT64 ZeroBits,
	UINT64* RegionSize,
	ULONG AllocationType,
	ULONG Protect
	);


typedef void (*pfnKeUnstackDetachProcess)(
	PRKAPC_STATE ApcState
);

typedef NTSTATUS(*pfnNtCreateThreadEx)(
	OUT PHANDLE hThread, 
	IN ACCESS_MASK DesiredAccess, 
	IN PVOID ObjectAttributes, 
	IN HANDLE ProcessHandle, 
	IN PVOID lpStartAddress, 
	IN PVOID lpParameter, 
	IN ULONG Flags, 
	IN UINT64 StackZeroBits,
	IN UINT64 SizeOfStackCommit,
	IN UINT64 SizeOfStackReserve,
	PVOID lpBytesBuffer);


typedef void* (*pfnPsGetCurrentThread)();  

typedef NTSTATUS (NTAPI *pfnZwClose)(
	HANDLE Handle
);

typedef KPROCESSOR_MODE (*pfnExGetPreviousMode)();

typedef PVOID(*pfnPsGetProcessWow64Process)(void* Process);