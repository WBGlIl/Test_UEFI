#pragma once


#ifdef __cplusplus
extern "C" {
#endif
#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiRuntimeLib.h>
#include <Library/DebugLib.h>
#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Protocol/LoadedImage.h>
#include <Library/DevicePathLib.h>
#include "ntdef.h"
#include "Ntke.h"

KLDR_DATA_TABLE_ENTRY GetModule(LIST_ENTRY* list, const CHAR16* name);
UINT64 FindPattern(VOID* baseAddress, UINT64 size, const CHAR8* pattern);
UINT64 FindPatternImage(VOID* base, const CHAR8* pattern);
VOID CopyMemory(VOID* destination, VOID* source, UINTN size);
UINT64 GetExport(VOID* base, const CHAR8* functionName);


#ifdef __cplusplus
}
#endif
