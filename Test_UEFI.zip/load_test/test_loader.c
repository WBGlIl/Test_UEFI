#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/DebugLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/DevicePathLib.h>
#include <Protocol/SimpleFileSystem.h>

const UINT32 _gDriverUnloadImageCount = 1;
extern CONST UINT32 _gUefiDriverRevision = 0;
CHAR8 *gEfiCallerBaseName = "test_loader";

static CHAR16 *gRuntimeDriverImagePath = L"\\EFI\\Microsoft\\Boot\\Test.efi";

EFI_STATUS LocateFile(IN CHAR16* ImagePath, OUT EFI_DEVICE_PATH** DevicePath)
{
	EFI_FILE_IO_INTERFACE *ioDevice;
	EFI_FILE_HANDLE handleRoots, bootFile;
	EFI_HANDLE* handleArray;
	UINTN nbHandles, i;
	EFI_STATUS efistatus;

	*DevicePath = (EFI_DEVICE_PATH *)NULL;
	efistatus = gBS->LocateHandleBuffer(ByProtocol, &gEfiSimpleFileSystemProtocolGuid, NULL, &nbHandles, &handleArray);
	if (EFI_ERROR(efistatus))
		return efistatus;
	for (i = 0; i < nbHandles; i++)
	{
		efistatus = gBS->HandleProtocol(handleArray[i], &gEfiSimpleFileSystemProtocolGuid, (void**)&ioDevice);
		if (efistatus != EFI_SUCCESS)
			continue;

		efistatus = ioDevice->OpenVolume(ioDevice, &handleRoots);
		if (EFI_ERROR(efistatus))
			continue;

		efistatus = handleRoots->Open(handleRoots, &bootFile, ImagePath, EFI_FILE_MODE_READ, EFI_FILE_READ_ONLY);
		if (!EFI_ERROR(efistatus))
		{
			handleRoots->Close(bootFile);
			*DevicePath = FileDevicePath(handleArray[i], ImagePath);
			break;
		}
	}

	return efistatus;
}

EFI_STATUS ImageLoad(IN EFI_HANDLE ParentHandle, IN EFI_DEVICE_PATH* DevicePath, OUT EFI_HANDLE* ImageHandle)
{
	EFI_STATUS status = EFI_NOT_FOUND;
	status = gBS->LoadImage(FALSE, ParentHandle, DevicePath, NULL, 0, ImageHandle);
	if (status != EFI_SUCCESS)
	{
		Print(L"[!] LoadImage error = %X\r\n", status);
	}

	return status;
}

EFI_STATUS EFIAPI UefiMain(IN EFI_HANDLE ImageHandle, IN EFI_SYSTEM_TABLE* SystemTable)
{
	EFI_STATUS status;
	EFI_DEVICE_PATH* RuntimeDriverDevicePath = NULL;
	EFI_HANDLE RuntimeDriverHandle = NULL;
	status = LocateFile(gRuntimeDriverImagePath, &RuntimeDriverDevicePath);
	if (EFI_ERROR(status)) {

	}
	status = ImageLoad(ImageHandle, RuntimeDriverDevicePath, &RuntimeDriverHandle);
	if (EFI_ERROR(status))
	{

	}
	status = gBS->StartImage(RuntimeDriverHandle, NULL, NULL);
	if (EFI_ERROR(status)) {

	}

	return status;
}



EFI_STATUS EFIAPI UefiUnload(IN EFI_HANDLE ImageHandle)
{
	return 0;
}
